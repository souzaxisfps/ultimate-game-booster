package com.ultimate.gamebooster

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager

object AppRepo {
    private val exact = setOf(
        "android", "com.android.vending", "moe.shizuku.privileged.api", "com.topjohnwu.magisk"
    )
    private val prefixes = listOf(
        "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.providers.",
        "com.android.inputmethod", "com.android.launcher", "com.android.permissioncontroller",
        "com.android.packageinstaller", "com.android.bluetooth", "com.android.nfc",
        "com.android.server.", "com.android.networkstack", "com.android.cellbroadcast",
        "com.android.shell", "com.android.keychain", "com.android.certinstaller",
        "com.android.se", "com.android.companiondevicemanager", "com.android.telephony",
        "com.android.emergency", "com.android.stk", "com.android.mms.service",
        "com.android.webview", "com.google.android.gms", "com.google.android.gsf",
        "com.google.android.webview", "com.google.android.permissioncontroller",
        "com.google.android.packageinstaller", "com.google.android.networkstack",
        "com.google.android.inputmethod", "com.google.android.ext",
        "com.google.android.apps.nexuslauncher", "com.google.android.dialer",
        "com.google.android.apps.messaging", "com.qualcomm", "com.qti", "vendor.qti",
        "org.codeaurora", "rikka.shizuku"
    )

    /** Apps essenciais dinâmicos: este app, launcher, teclado, discador e SMS padrão. */
    fun dynamic(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val s = mutableSetOf(ctx.packageName)
        try {
            pm.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName?.let { s += it }
        } catch (e: Exception) { }
        try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { s += it }
        } catch (e: Exception) { }
        try {
            ctx.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s += it }
        } catch (e: Exception) { }
        try {
            Telephony.Sms.getDefaultSmsPackage(ctx)?.let { s += it }
        } catch (e: Exception) { }
        return s
    }

    fun isProtected(ai: ApplicationInfo, dyn: Set<String>): Boolean {
        val p = ai.packageName
        if (p in dyn || p in exact) return true
        if (prefixes.any { p.startsWith(it) }) return true
        if (ai.uid < 10000) return true               // UID de sistema
        if ((ai.flags and 0x8) != 0) return true      // FLAG_PERSISTENT
        return false
    }

    fun list(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val dyn = dynamic(ctx)
        val flags = PackageManager.MATCH_DISABLED_COMPONENTS or PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS
        return pm.getInstalledApplications(flags).map { ai ->
            AppItem(
                ai.packageName,
                ai.loadLabel(pm).toString(),
                (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                ai.enabled,
                isProtected(ai, dyn)
            )
        }.sortedBy { it.label.lowercase() }
    }
}
