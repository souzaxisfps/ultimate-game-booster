package com.ultimate.gamebooster

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Execução de comandos de shell via Shizuku (permissão concedida pelo usuário). */
object Shell {
    data class Res(val code: Int, val out: String) {
        val ok: Boolean get() = code == 0
    }

    fun available(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = available() && try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request() {
        try { Shizuku.requestPermission(1001) } catch (e: Throwable) { /* Shizuku não está rodando */ }
    }

    fun exec(cmd: String): Res {
        if (!granted()) return Res(-1, "Shizuku sem permissão")
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            Res(p.waitFor(), out.trim())
        } catch (e: Throwable) {
            Res(-1, e.message ?: "erro")
        }
    }
}
