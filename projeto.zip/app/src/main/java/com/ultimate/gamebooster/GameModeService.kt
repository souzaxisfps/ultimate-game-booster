package com.ultimate.gamebooster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameModeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    companion object {
        const val ACTION_START = "ugb.START"
        const val ACTION_STOP = "ugb.STOP"
        const val EXTRA_PROFILE = "profile"
        private const val CH = "ugb_game"
        private const val NID = 41

        fun start(ctx: Context, profileId: String) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, GameModeService::class.java).setAction(ACTION_START).putExtra(EXTRA_PROFILE, profileId)
            )
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, GameModeService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        if (job?.isActive == true) return START_NOT_STICKY
        val store = Store.get(this)
        val all = store.profiles()
        val prof = all.firstOrNull { it.id == intent?.getStringExtra(EXTRA_PROFILE) } ?: all.first()
        startFg("Aplicando ${prof.name}...")
        job = scope.launch {
            Engine.start(applicationContext, prof)
            monitor(prof)
        }
        return START_NOT_STICKY
    }

    private suspend fun monitor(p: Profile) {
        val m = Metrics(applicationContext)
        var lastWarn = 0L
        while (true) {
            val s = m.sample()
            Engine.state.update { it.copy(sample = s) }
            val t = s.tempC
            if (t != null && t >= p.tempLimit && System.currentTimeMillis() - lastWarn > 60_000) {
                lastWarn = System.currentTimeMillis()
                Engine.log("Temperatura alta: ${"%.1f".format(t)}°C (limite ${p.tempLimit}°C)")
            }
            val txt = "RAM livre ${s.availMb} MB" +
                (t?.let { " • ${"%.1f".format(it)}°C" } ?: "") +
                (s.cpu?.let { " • CPU ${it.toInt()}%" } ?: "")
            getSystemService(NotificationManager::class.java).notify(NID, build(txt))
            delay(2000)
        }
    }

    private fun shutdown() {
        scope.launch {
            job?.cancelAndJoin()
            Engine.stop(applicationContext)
            withContext(Dispatchers.Main) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun build(text: String): Notification {
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, GameModeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("GAME MODE ativo")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi)
            .addAction(0, "Encerrar e restaurar", stopPi)
            .build()
    }

    private fun startFg(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Game Mode", NotificationManager.IMPORTANCE_LOW))
        val n = build(text)
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NID, n)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
