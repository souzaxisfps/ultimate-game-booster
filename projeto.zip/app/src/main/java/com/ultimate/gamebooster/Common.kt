package com.ultimate.gamebooster

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*

fun tempColor(t: Float?): Color = when {
    t == null -> TextDim
    t < 40f -> Good
    t < 45f -> Warn
    else -> Bad
}

fun openAppInfo(ctx: android.content.Context, pkg: String) {
    ctx.startActivity(
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun launchApp(ctx: android.content.Context, pkg: String): Boolean {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    return true
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(sub, color = TextDim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Neon, checkedThumbColor = Color.Black)
        )
    }
}

@Composable
fun ProfileSelector(vm: MainViewModel) {
    var dialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.profiles, key = { it.id }) { p ->
                FilterChip(
                    selected = p.id == vm.activeId,
                    onClick = { vm.setActive(p.id) },
                    label = { Text(p.name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Neon, selectedLabelColor = Color.Black
                    )
                )
            }
        }
        IconButton(onClick = { dialog = true }) { Icon(Icons.Rounded.Add, "Novo perfil", tint = Neon) }
        if (!vm.active.builtIn) {
            IconButton(onClick = { vm.deleteActive() }) { Icon(Icons.Rounded.Delete, "Excluir perfil", tint = Bad) }
        }
    }
    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            containerColor = Panel,
            title = { Text("Novo perfil personalizado") },
            text = {
                Column {
                    Text("Copia as opções do perfil atual (${vm.active.name}).", color = TextDim, fontSize = 12.sp)
                    OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Nome") })
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.newProfile(name); name = ""; dialog = false }) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { dialog = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun GamePickerDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = vm.apps.filter {
        !it.isSystem && !it.isProtected && (q.isBlank() || it.label.contains(q, true))
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Escolher jogo") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Buscar") })
                LazyColumn(Modifier.height(320.dp)) {
                    items(list, key = { it.pkg }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.setGame(a.pkg); onDismiss() }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(a.pkg, 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(a.label, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
fun GameTargetRow(vm: MainViewModel) {
    val ctx = LocalContext.current
    var pick by remember { mutableStateOf(false) }
    val label = vm.apps.firstOrNull { it.pkg == vm.gamePkg }?.label
        ?: vm.gamePkg.ifEmpty { "Nenhum jogo escolhido" }
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (vm.gamePkg.isNotEmpty()) { AppIcon(vm.gamePkg, 36.dp); Spacer(Modifier.width(10.dp)) }
        Column(Modifier.weight(1f)) {
            Text("Jogo alvo", color = TextDim, fontSize = 11.sp)
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        TextButton(onClick = { pick = true }) { Text("Escolher") }
        if (vm.gamePkg.isNotEmpty()) TextButton(onClick = { launchApp(ctx, vm.gamePkg) }) { Text("Abrir") }
    }
    if (pick) GamePickerDialog(vm) { pick = false }
}
