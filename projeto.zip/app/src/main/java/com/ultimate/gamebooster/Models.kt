package com.ultimate.gamebooster

data class Profile(
    val id: String,
    val name: String,
    val builtIn: Boolean,
    val apps: Set<String> = emptySet(),
    val disableApps: Boolean = true,
    val restrictBackground: Boolean = true,
    val killBackground: Boolean = true,
    val gameMode: Boolean = false,
    val reduceAnimations: Boolean = false,
    val tempLimit: Int = 43
)

/** Registro de uma alteração feita pelo app (para restaurar depois). */
data class Change(val type: String, val key: String, val original: String)

data class Sample(
    val totalMb: Long,
    val availMb: Long,
    val cpu: Float?,
    val gpu: Float?,
    val tempC: Float?,
    val fgPkg: String?
) {
    val usedMb: Long get() = totalMb - availMb
    val usedPct: Float get() = if (totalMb > 0) usedMb * 100f / totalMb else 0f
}

data class GameState(
    val active: Boolean = false,
    val profileName: String = "",
    val startedAt: Long = 0L,
    val log: List<String> = emptyList(),
    val sample: Sample? = null
)

data class AppItem(
    val pkg: String,
    val label: String,
    val isSystem: Boolean,
    val enabled: Boolean,
    val isProtected: Boolean
)

data class Consumer(val pkg: String, val label: String, val mb: Int)

data class FrameStats(
    val total: Int,
    val janky: Int,
    val jankyPct: String,
    val p50: String,
    val p90: String,
    val p95: String,
    val p99: String
)
