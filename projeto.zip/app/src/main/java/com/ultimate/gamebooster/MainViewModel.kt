package com.ultimate.gamebooster

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val store = Store.get(app)
    private val metrics = Metrics(app)

    var sample by mutableStateOf<Sample?>(null); private set
    val ramHist = mutableStateListOf<Float>()
    val cpuHist = mutableStateListOf<Float>()
    val tempHist = mutableStateListOf<Float>()

    var apps by mutableStateOf<List<AppItem>>(emptyList()); private set
    var loadingApps by mutableStateOf(false); private set

    var profiles by mutableStateOf(store.profiles()); private set
    var activeId by mutableStateOf(store.activeId); private set
    val active: Profile get() = profiles.firstOrNull { it.id == activeId } ?: profiles.first()

    /** 0 = Shizuku não está rodando, 1 = sem permissão, 2 = pronto */
    var shizuku by mutableIntStateOf(0); private set
    var usage by mutableStateOf(false); private set
    var pending by mutableIntStateOf(store.changes().size); private set

    var consumers by mutableStateOf<List<Consumer>>(emptyList()); private set
    var frame by mutableStateOf<FrameStats?>(null); private set
    var frameNote by mutableStateOf("")
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)

    var gamePkg by mutableStateOf(store.gamePkg); private set
    var allowSys by mutableStateOf(store.allowSystemDisable); private set

    init { loadApps() }

    suspend fun sampleLoop() {
        while (true) {
            val (s, sh, us) = withContext(Dispatchers.IO) {
                val s = metrics.sample()
                val sh = when {
                    !Shell.available() -> 0
                    !Shell.granted() -> 1
                    else -> 2
                }
                Triple(s, sh, Metrics.hasUsageAccess(app))
            }
            sample = s
            push(ramHist, s.usedPct)
            s.cpu?.let { push(cpuHist, it) }
            s.tempC?.let { push(tempHist, it) }
            shizuku = sh
            usage = us
            pending = store.changes().size
            delay(2000)
        }
    }

    private fun push(l: SnapshotStateList<Float>, v: Float) {
        l.add(v)
        if (l.size > 60) l.removeAt(0)
    }

    fun loadApps() {
        viewModelScope.launch {
            loadingApps = true
            apps = withContext(Dispatchers.IO) { AppRepo.list(app) }
            loadingApps = false
        }
    }

    // ----- perfis -----
    private fun saveProfiles(list: List<Profile>) { profiles = list; store.saveProfiles(list) }

    fun updateActive(f: (Profile) -> Profile) =
        saveProfiles(profiles.map { if (it.id == activeId) f(it) else it })

    fun setActive(id: String) { activeId = id; store.activeId = id }
    fun toggleApp(pkg: String) =
        updateActive { it.copy(apps = if (pkg in it.apps) it.apps - pkg else it.apps + pkg) }
    fun selectMany(pkgs: Collection<String>) = updateActive { it.copy(apps = it.apps + pkgs) }
    fun clearApps() = updateActive { it.copy(apps = emptySet()) }

    fun newProfile(name: String) {
        val id = "p" + System.currentTimeMillis()
        val n = name.trim().uppercase().ifBlank { "PERSONALIZADO" }
        saveProfiles(profiles + active.copy(id = id, name = n, builtIn = false))
        setActive(id)
    }

    fun deleteActive() {
        if (active.builtIn) return
        saveProfiles(profiles.filter { it.id != activeId })
        setActive(profiles.first().id)
    }

    fun setGame(pkg: String) { gamePkg = pkg; store.gamePkg = pkg }
    fun setAllowSys(v: Boolean) { allowSys = v; store.allowSystemDisable = v }

    // ----- ações -----
    fun startGame() { GameModeService.start(app, activeId) }
    fun stopGame() { GameModeService.stop(app) }

    fun applySelectedNow() = viewModelScope.launch {
        busy = true
        val p = active
        val n = withContext(Dispatchers.IO) { Engine.applyApps(app, p) }
        pending = store.changes().size
        loadApps()
        message = "$n app(s) afetado(s) pelo perfil ${p.name}."
        busy = false
    }

    fun restoreNow() = viewModelScope.launch {
        busy = true
        val (ok, fail) = withContext(Dispatchers.IO) { Engine.restoreAll(app) }
        pending = store.changes().size
        loadApps()
        message = if (ok == 0 && fail == 0) "Nada para restaurar."
        else if (fail == 0) "Tudo restaurado ($ok)." else "Restaurado: $ok. Falhas: $fail (verifique o Shizuku)."
        busy = false
    }

    fun refreshConsumers() = viewModelScope.launch {
        busy = true
        consumers = withContext(Dispatchers.IO) { Engine.topConsumers(app) }
        if (consumers.isEmpty()) message = "Lista indisponível: ative o Shizuku para ver o consumo por app."
        busy = false
    }

    fun smartOptimize() = viewModelScope.launch {
        busy = true
        val keep = setOfNotNull(gamePkg.ifEmpty { null }, sample?.fgPkg)
        message = withContext(Dispatchers.IO) { Engine.smartOptimize(app, keep) }
        consumers = withContext(Dispatchers.IO) { Engine.topConsumers(app) }
        busy = false
    }

    fun kill(pkg: String) = viewModelScope.launch {
        withContext(Dispatchers.IO) { Engine.killOne(app, pkg) }
        message = "Processo encerrado."
        consumers = withContext(Dispatchers.IO) { Engine.topConsumers(app) }
    }

    private fun targetPkg(): String = gamePkg.ifEmpty { sample?.fgPkg ?: "" }

    fun resetFrames() = viewModelScope.launch {
        val p = targetPkg()
        if (p.isEmpty()) { message = "Escolha o jogo primeiro."; return@launch }
        withContext(Dispatchers.IO) { Engine.resetFrames(p) }
        frame = null
        frameNote = "Contador zerado. Jogue um pouco e toque em Medir."
    }

    fun measureFrames() = viewModelScope.launch {
        val p = targetPkg()
        if (p.isEmpty()) { message = "Escolha o jogo primeiro."; return@launch }
        busy = true
        val f = withContext(Dispatchers.IO) { Engine.frameStats(p) }
        frame = f
        frameNote = when {
            f == null -> "Sem dados (Shizuku inativo ou o jogo não está em execução)."
            f.total == 0 -> "O jogo não informa frames ao Android (comum em jogos com engine própria). Não há como medir o FPS real sem root."
            else -> "Dados reais do Android (gfxinfo) para o jogo."
        }
        busy = false
    }
}
