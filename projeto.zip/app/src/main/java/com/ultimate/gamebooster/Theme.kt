package com.ultimate.gamebooster

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

val Bg = Color(0xFF05080F)
val Panel = Color(0xFF0C1424)
val CardBg = Color(0xFF111C33)
val Neon = Color(0xFF00D4FF)
val NeonDim = Color(0xFF0A7FA6)
val Good = Color(0xFF00E676)
val Warn = Color(0xFFFFC400)
val Bad = Color(0xFFFF5252)
val TextDim = Color(0xFF8FA3C0)

@Composable
fun UgbTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon, onPrimary = Color.Black, background = Bg, surface = Panel,
            onSurface = Color.White, onBackground = Color.White, secondary = NeonDim,
            surfaceVariant = CardBg, outline = NeonDim
        ),
        content = content
    )
}

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .border(1.dp, Neon.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
fun SectionTitle(t: String) {
    Text(
        t, color = Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp,
        modifier = Modifier.padding(vertical = 6.dp)
    )
}

@Composable
fun NeonButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true,
    color: Color = Neon,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(56.dp),
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        border = if (filled) null else BorderStroke(1.dp, color),
        colors = if (filled) ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.Black)
        else ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = color)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun Gauge(value: Float?, label: String, unit: String, color: Color = Neon, max: Float = 100f, modifier: Modifier = Modifier) {
    val anim by animateFloatAsState(((value ?: 0f) / max).coerceIn(0f, 1f), tween(600), label = "gauge")
    Box(modifier.size(92.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            val st = Stroke(width = 9.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Color(0xFF1B2A47), 135f, 270f, false, style = st)
            drawArc(color, 135f, 270f * anim, false, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (value == null) "—" else "${value.toInt()}$unit",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp
            )
            Text(label, color = TextDim, fontSize = 11.sp)
        }
    }
}

@Composable
fun LineChart(data: List<Float>, modifier: Modifier = Modifier, max: Float = 100f, color: Color = Neon) {
    Canvas(modifier.fillMaxWidth().height(90.dp)) {
        val w = size.width
        val h = size.height
        for (i in 1..3) drawLine(Color(0xFF1B2A47), Offset(0f, h * i / 4f), Offset(w, h * i / 4f), 1f)
        if (data.size < 2) return@Canvas
        val step = w / 59f
        val path = Path()
        data.forEachIndexed { i, v ->
            val x = w - (data.size - 1 - i) * step
            val y = h - (v / max).coerceIn(0f, 1f) * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color.copy(alpha = 0.25f), style = Stroke(width = 8f))
        drawPath(path, color, style = Stroke(width = 3f, cap = StrokeCap.Round))
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }
    }
    if (bmp != null) Image(bmp, null, Modifier.size(size))
    else Box(Modifier.size(size).background(CardBg))
}
