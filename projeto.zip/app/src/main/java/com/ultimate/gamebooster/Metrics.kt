package com.ultimate.gamebooster

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Process
import java.io.File

/** Leituras reais do aparelho. Valores indisponíveis retornam null (nunca inventados). */
class Metrics(private val ctx: Context) {
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var lastEventTime = 0L
    private var fg: String? = null
    private var gpuOk = true

    companion object {
        fun hasUsageAccess(ctx: Context): Boolean = try {
            val a = ctx.getSystemService(AppOpsManager::class.java)
            a.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
            ) == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }
    }

    fun sample(): Sample {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return Sample(mi.totalMem / 1048576, mi.availMem / 1048576, cpu(), gpu(), temp(), foreground())
    }

    private fun cpu(): Float? {
        var line: String? = try { File("/proc/stat").useLines { it.firstOrNull() } } catch (e: Exception) { null }
        if (line == null && Shell.granted()) {
            val r = Shell.exec("head -n 1 /proc/stat")
            if (r.ok) line = r.out
        }
        if (line == null || !line.startsWith("cpu")) return null
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) return null
        val total = p.take(8).sum()
        val idle = p[3] + p[4]
        val first = lastTotal == 0L
        val dT = total - lastTotal
        val dI = idle - lastIdle
        lastTotal = total
        lastIdle = idle
        if (first || dT <= 0) return null
        return ((dT - dI) * 100f / dT).coerceIn(0f, 100f)
    }

    private fun gpu(): Float? {
        if (!gpuOk || !Shell.granted()) return null
        val r = Shell.exec("cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")
        if (!r.ok) { gpuOk = false; return null }
        val v = Regex("[0-9]+").find(r.out)?.value?.toFloatOrNull()
        if (v == null) gpuOk = false
        return v
    }

    private fun temp(): Float? {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else t / 10f
    }

    private fun foreground(): String? {
        if (!hasUsageAccess(ctx)) return null
        return try {
            val usm = ctx.getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val from = if (lastEventTime == 0L) now - 3_600_000L else lastEventTime - 1000L
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) fg = e.packageName
            }
            lastEventTime = now
            fg
        } catch (ex: Exception) { null }
    }
}
