package com.ultimate.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/**
 * Motor do app. Toda alteração é registrada em Store.changes() para ser desfeita
 * por restoreAll(). Só usa comandos reais via Shizuku; sem Shizuku, apenas
 * killBackgroundProcesses (API oficial).
 */
object Engine {
    val state = MutableStateFlow(GameState())
    private val pkgRe = Regex("^[A-Za-z][A-Za-z0-9_.]*$")
    private val numRe = Regex("^[0-9.]+$")
    private val settingKeys = listOf(
        "window_animation_scale", "transition_animation_scale", "animator_duration_scale"
    )

    fun log(msg: String) {
        state.update { it.copy(log = (listOf(msg) + it.log).take(100)) }
    }

    private fun record(ctx: Context, c: Change) {
        val st = Store.get(ctx)
        val l = st.changes()
        if (l.none { it.type == c.type && it.key == c.key }) {
            l.add(c)
            st.saveChanges(l)
        }
    }

    private fun appopsOriginal(pkg: String): String {
        val r = Shell.exec("cmd appops get $pkg RUN_IN_BACKGROUND")
        val m = Regex("RUN_IN_BACKGROUND:\\s*(\\w+)").find(r.out)?.groupValues?.get(1)?.lowercase()
        return if (m == null || m == "allow") "default"
        else if (m in setOf("ignore", "deny", "default", "foreground")) m
        else "default"
    }

    /** Aplica a lista de apps do perfil. Retorna quantos apps foram afetados. */
    fun applyApps(ctx: Context, p: Profile): Int {
        val pm = ctx.packageManager
        val st = Store.get(ctx)
        val dyn = AppRepo.dynamic(ctx)
        val am = ctx.getSystemService(ActivityManager::class.java)
        val sh = Shell.granted()
        var n = 0
        for (pkg in p.apps) {
            if (!pkgRe.matches(pkg) || pkg == st.gamePkg) continue
            val ai = try { pm.getApplicationInfo(pkg, 0) } catch (e: Exception) { continue }
            val label = ai.loadLabel(pm).toString()
            if (AppRepo.isProtected(ai, dyn)) { log("Protegido, ignorado: $label"); continue }
            if (!sh) {
                if (p.killBackground) {
                    am.killBackgroundProcesses(pkg); log("Processo encerrado: $label"); n++
                }
                continue
            }
            val isSys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (p.disableApps && ai.enabled && (!isSys || st.allowSystemDisable)) {
                val r = Shell.exec("pm disable-user --user 0 $pkg")
                if (r.ok) {
                    record(ctx, Change("disable", pkg, "")); log("Desativado: $label"); n++
                } else log("Falha ao desativar $label: ${r.out.take(80)}")
                continue
            }
            var did = false
            if (p.restrictBackground) {
                val orig = appopsOriginal(pkg)
                if (Shell.exec("cmd appops set $pkg RUN_IN_BACKGROUND ignore").ok) {
                    record(ctx, Change("appops", pkg, orig)); did = true
                } else log("Falha ao restringir $label")
            }
            if (p.killBackground && Shell.exec("am force-stop $pkg").ok) did = true
            if (did) { log("Restrito/encerrado: $label"); n++ }
        }
        return n
    }

    fun applyTuning(ctx: Context, p: Profile) {
        if (!Shell.granted()) return
        if (p.reduceAnimations) {
            for (k in settingKeys) {
                val cur = Shell.exec("settings get global $k").out.trim()
                val orig = if (numRe.matches(cur)) cur else "null"
                if (Shell.exec("settings put global $k 0.5").ok) {
                    record(ctx, Change("setting", k, orig)); log("Animações reduzidas ($k)")
                }
            }
        }
        val g = Store.get(ctx).gamePkg
        if (p.gameMode && g.isNotEmpty() && pkgRe.matches(g)) {
            val tries = listOf(
                "cmd game set --mode performance $g",
                "cmd game set --mode 2 $g",
                "cmd game mode performance $g"
            )
            var ok = false
            for (t in tries) {
                val r = Shell.exec(t)
                if (r.ok && !r.out.contains("rror", true) && !r.out.contains("nknown", true)) { ok = true; break }
            }
            if (ok) {
                record(ctx, Change("gamemode", g, "")); log("Modo de desempenho do Android ativado para o jogo")
            } else log("Este Android não aceitou o modo de desempenho por shell (depende do aparelho).")
        }
    }

    fun start(ctx: Context, p: Profile) {
        state.value = GameState(active = true, profileName = p.name, startedAt = System.currentTimeMillis())
        log("GAME MODE iniciado: ${p.name}")
        if (!Shell.granted()) log("Shizuku inativo: só é possível encerrar processos em segundo plano.")
        val n = applyApps(ctx, p)
        applyTuning(ctx, p)
        log("$n app(s) afetado(s). Monitorando...")
    }

    fun stop(ctx: Context) {
        val (ok, fail) = restoreAll(ctx)
        log(if (fail == 0) "Restauração concluída ($ok alteração(ões))." else "Restauração parcial: $ok ok, $fail falharam.")
        state.update { it.copy(active = false) }
    }

    /** Desfaz tudo o que o app registrou. Retorna (restauradas, falhas). */
    fun restoreAll(ctx: Context): Pair<Int, Int> {
        val st = Store.get(ctx)
        val list = st.changes()
        if (list.isEmpty()) return 0 to 0
        if (!Shell.granted()) {
            log("Para restaurar é preciso o Shizuku ativo e autorizado.")
            return 0 to list.size
        }
        var ok = 0
        var fail = 0
        val remaining = mutableListOf<Change>()
        for (c in list.reversed()) {
            val r = when (c.type) {
                "disable" -> Shell.exec("pm enable ${c.key}")
                "appops" -> Shell.exec("cmd appops set ${c.key} RUN_IN_BACKGROUND ${c.original}")
                "setting" ->
                    if (c.original == "null" || !numRe.matches(c.original)) Shell.exec("settings delete global ${c.key}")
                    else Shell.exec("settings put global ${c.key} ${c.original}")
                "gamemode" -> { Shell.exec("cmd game reset ${c.key}"); Shell.Res(0, "") }
                else -> Shell.Res(0, "")
            }
            val gone = r.out.contains("Unknown package", true) || r.out.contains("not found", true)
            if (r.ok || gone) { ok++; log("Restaurado: ${c.type} ${c.key}") } else { fail++; remaining += c }
        }
        st.saveChanges(remaining.reversed())
        return ok to fail
    }

    // ---------- RAM ----------

    fun topConsumers(ctx: Context): List<Consumer> {
        if (!Shell.granted()) return emptyList()
        val r = Shell.exec("dumpsys meminfo")
        if (!r.ok) return emptyList()
        val pm = ctx.packageManager
        val re = Regex("^\\s*([0-9.,]+)K:\\s+(\\S+)\\s+\\(pid")
        var inSec = false
        val map = LinkedHashMap<String, Int>()
        for (line in r.out.lineSequence()) {
            if (line.startsWith("Total PSS by process")) { inSec = true; continue }
            if (!inSec) continue
            if (line.isBlank()) break
            val m = re.find(line) ?: continue
            val kb = m.groupValues[1].replace(".", "").replace(",", "").toLongOrNull() ?: continue
            val pkg = m.groupValues[2].substringBefore(':')
            map[pkg] = (map[pkg] ?: 0) + (kb / 1024).toInt()
        }
        val out = mutableListOf<Consumer>()
        for ((pkg, mb) in map) {
            val label = try { pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString() } catch (e: Exception) { null }
            if (label != null) out += Consumer(pkg, label, mb)
        }
        return out.sortedByDescending { it.mb }.take(15)
    }

    fun killOne(ctx: Context, pkg: String): Boolean {
        if (!pkgRe.matches(pkg)) return false
        return if (Shell.granted()) Shell.exec("am force-stop $pkg").ok
        else { ctx.getSystemService(ActivityManager::class.java).killBackgroundProcesses(pkg); true }
    }

    /** Encerra os maiores consumidores seguros (nunca apps essenciais, o jogo ou este app). */
    fun smartOptimize(ctx: Context, keep: Set<String>): String {
        val am = ctx.getSystemService(ActivityManager::class.java)
        fun avail(): Long {
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); return mi.availMem / 1048576
        }
        if (!Shell.granted()) return "A otimização inteligente precisa do Shizuku para ver o consumo por app."
        val before = avail()
        val pm = ctx.packageManager
        val dyn = AppRepo.dynamic(ctx)
        val targets = topConsumers(ctx).filter { c ->
            c.mb >= 40 && c.pkg !in keep && c.pkg != ctx.packageName &&
                try { !AppRepo.isProtected(pm.getApplicationInfo(c.pkg, 0), dyn) } catch (e: Exception) { false }
        }.take(10)
        if (targets.isEmpty()) return "Nada seguro para encerrar agora."
        var n = 0
        for (t in targets) if (Shell.exec("am force-stop ${t.pkg}").ok) n++
        Thread.sleep(1500)
        return "Encerrou $n app(s). RAM livre: $before MB → ${avail()} MB. O Android pode reabrir alguns sozinho."
    }

    // ---------- FPS ----------

    fun resetFrames(pkg: String) {
        if (pkgRe.matches(pkg)) Shell.exec("dumpsys gfxinfo $pkg reset")
    }

    fun frameStats(pkg: String): FrameStats? {
        if (!pkgRe.matches(pkg) || !Shell.granted()) return null
        val r = Shell.exec("dumpsys gfxinfo $pkg")
        if (!r.ok) return null
        fun num(re: String) = Regex(re).find(r.out)?.groupValues?.get(1)
        val total = num("Total frames rendered:\\s*(\\d+)")?.toIntOrNull() ?: return null
        val j = Regex("Janky frames:\\s*(\\d+)\\s*\\(([0-9.]+)%\\)").find(r.out)
        return FrameStats(
            total, j?.groupValues?.get(1)?.toIntOrNull() ?: 0, j?.groupValues?.get(2) ?: "0",
            num("50th percentile:\\s*(\\d+ms)") ?: "—", num("90th percentile:\\s*(\\d+ms)") ?: "—",
            num("95th percentile:\\s*(\\d+ms)") ?: "—", num("99th percentile:\\s*(\\d+ms)") ?: "—"
        )
    }

    fun bottlenecks(s: Sample?, limit: Int): List<String> {
        if (s == null) return listOf("Sem dados ainda.")
        val out = mutableListOf<String>()
        s.tempC?.let { if (it >= limit) out += "Temperatura alta (${"%.1f".format(it)}°C): o sistema pode reduzir o clock (thermal throttling)." }
        if (s.totalMb > 0 && s.availMb * 100f / s.totalMb < 15f) out += "Pouca RAM livre (<15%): o Android pode encerrar apps e o jogo pode recarregar."
        s.cpu?.let { if (it > 85f) out += "CPU acima de 85%: provável gargalo de processamento." }
        s.gpu?.let { if (it > 90f) out += "GPU acima de 90%: gargalo gráfico; reduzir os gráficos do jogo ajuda." }
        if (out.isEmpty()) out += "Nenhum gargalo detectado neste momento."
        return out
    }
}
