package com.ultimate.gamebooster

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay

@Composable
fun FpsScreen(vm: MainViewModel, go: (Int) -> Unit) {
    val s = vm.sample
    val shown = vm.gamePkg.ifEmpty { s?.fgPkg ?: "" }
    val limit = vm.active.tempLimit
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("OTIMIZADOR DE FPS", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        NeonCard {
            GameTargetRow(vm)
            if (vm.gamePkg.isEmpty()) {
                Text(
                    "App em primeiro plano: " + (s?.fgPkg ?: if (vm.usage) "nenhum" else "ative o acesso de uso"),
                    color = TextDim, fontSize = 12.sp
                )
            }
        }
        NeonCard {
            SectionTitle("LEITURAS REAIS")
            Text("CPU: " + (s?.cpu?.let { "${it.toInt()}%" } ?: "indisponível (requer Shizuku)"), color = Color.White)
            Text("GPU: " + (s?.gpu?.let { "${it.toInt()}%" } ?: "indisponível neste aparelho"), color = Color.White)
            Text(
                "Temperatura (bateria): " + (s?.tempC?.let { "${"%.1f".format(it)}°C" } ?: "—"),
                color = tempColor(s?.tempC)
            )
        }
        NeonCard {
            SectionTitle("POSSÍVEIS GARGALOS")
            Engine.bottlenecks(s, limit).forEach { Text("• $it", color = Color.White, fontSize = 13.sp) }
        }
        NeonCard {
            SectionTitle("ESTABILIDADE DE FRAMES")
            Text(
                "Mede quadros lentos (janky) reportados pelo Android para o jogo: " +
                    if (shown.isEmpty()) "escolha o jogo." else shown,
                color = TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.resetFrames() }, Modifier.weight(1f)) { Text("Zerar") }
                Button(
                    onClick = { vm.measureFrames() }, Modifier.weight(1f), enabled = !vm.busy,
                    colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black)
                ) { Text("Medir") }
            }
            vm.frame?.let { f ->
                if (f.total > 0) {
                    Spacer(Modifier.height(8.dp))
                    Text("Frames: ${f.total} • lentos: ${f.janky} (${f.jankyPct}%)", color = Color.White)
                    Text("Tempo por frame — p50 ${f.p50} • p90 ${f.p90} • p95 ${f.p95} • p99 ${f.p99}", color = TextDim, fontSize = 12.sp)
                }
            }
            if (vm.frameNote.isNotEmpty()) Text(vm.frameNote, color = Warn, fontSize = 12.sp)
        }
        NeonCard {
            SectionTitle("APLICAR")
            Text(
                "O perfil ${vm.active.name} reduz atividade em segundo plano e, no Game Mode, ativa o modo " +
                    "de desempenho do Android para o jogo quando o aparelho aceita. Nenhum aumento de FPS é prometido: " +
                    "o limite é o hardware.",
                color = TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            NeonButton("IR PARA O GAME MODE", filled = false) { go(4) }
        }
    }
}

@Composable
fun RamScreen(vm: MainViewModel) {
    val s = vm.sample
    LaunchedEffect(vm.shizuku) { if (vm.shizuku == 2 && vm.consumers.isEmpty()) vm.refreshConsumers() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("OTIMIZADOR DE RAM", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        NeonCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Gauge(s?.usedPct, "USADA", "%")
                Column(verticalArrangement = Arrangement.Center, modifier = Modifier.height(92.dp)) {
                    Text("Total: ${s?.totalMb ?: "—"} MB", color = Color.White)
                    Text("Usada: ${s?.usedMb ?: "—"} MB", color = Color.White)
                    Text("Livre: ${s?.availMb ?: "—"} MB", color = Good)
                }
            }
            LineChart(vm.ramHist)
        }
        NeonButton("OTIMIZAÇÃO INTELIGENTE", enabled = !vm.busy) { vm.smartOptimize() }
        Text(
            "Encerra os maiores consumidores que não são essenciais (nunca o jogo, o teclado, o launcher, " +
                "telefone/SMS ou o sistema). Não é \"limpeza\" falsa: usa force-stop real e o Android gerencia a memória.",
            color = TextDim, fontSize = 12.sp
        )
        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("MAIORES CONSUMIDORES")
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { vm.refreshConsumers() }) { Icon(Icons.Rounded.Refresh, "Atualizar", tint = Neon) }
            }
            if (vm.consumers.isEmpty()) {
                Text(
                    if (vm.shizuku == 2) "Sem dados ainda. Toque em atualizar."
                    else "O Android não permite ver o consumo de outros apps sem o Shizuku. Veja Configurações.",
                    color = TextDim, fontSize = 13.sp
                )
            }
            vm.consumers.forEach { c ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(c.pkg, 32.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.label, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${c.mb} MB", color = TextDim, fontSize = 12.sp)
                    }
                    TextButton(onClick = { vm.kill(c.pkg) }) { Text("Encerrar", color = Bad) }
                }
            }
        }
    }
}

@Composable
fun GameScreen(vm: MainViewModel) {
    val game by Engine.state.collectAsState()
    val p = vm.active
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(game.active) {
        while (game.active) { now = System.currentTimeMillis(); delay(1000) }
    }
    val secs = ((now - game.startedAt) / 1000).coerceAtLeast(0)
    val s = game.sample ?: vm.sample
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("GAME MODE", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        ProfileSelector(vm)
        NeonCard { GameTargetRow(vm) }

        if (game.active) {
            NeonCard {
                Text("ATIVO há %02d:%02d • %s".format(secs / 60, secs % 60, game.profileName), color = Good, fontWeight = FontWeight.Bold)
                Text("RAM livre: ${s?.availMb ?: "—"} MB • Temp: ${s?.tempC?.let { "%.1f°C".format(it) } ?: "—"} • CPU: ${s?.cpu?.let { "${it.toInt()}%" } ?: "—"}", color = Color.White, fontSize = 13.sp)
            }
            NeonButton("ENCERRAR E RESTAURAR TUDO", color = Bad) { vm.stopGame() }
        } else {
            NeonButton("INICIAR GAME MODE", enabled = !vm.busy) { vm.startGame() }
            if (vm.pending > 0) NeonButton("RESTAURAR ${vm.pending} ALTERAÇÃO(ÕES)", filled = false, color = Warn, enabled = !vm.busy) { vm.restoreNow() }
        }

        NeonCard {
            SectionTitle("PERSONALIZAR PERFIL ${p.name}")
            Text("${p.apps.size} app(s) selecionado(s) (edite na aba Apps)", color = TextDim, fontSize = 12.sp)
            ToggleRow("Desativar apps selecionados", "Usa pm disable-user (Shizuku). Reativados ao encerrar.", p.disableApps) { v -> vm.updateActive { it.copy(disableApps = v) } }
            ToggleRow("Restringir segundo plano", "AppOps RUN_IN_BACKGROUND (restaurado depois).", p.restrictBackground) { v -> vm.updateActive { it.copy(restrictBackground = v) } }
            ToggleRow("Encerrar processos", "force-stop nos selecionados ao iniciar.", p.killBackground) { v -> vm.updateActive { it.copy(killBackground = v) } }
            ToggleRow("Modo de desempenho do Android", "Game mode do sistema para o jogo alvo (se suportado).", p.gameMode) { v -> vm.updateActive { it.copy(gameMode = v) } }
            ToggleRow("Reduzir animações do sistema", "Escala 0,5x; valores originais são restaurados.", p.reduceAnimations) { v -> vm.updateActive { it.copy(reduceAnimations = v) } }
            Text("Alerta de temperatura: ${p.tempLimit}°C", color = Color.White, modifier = Modifier.padding(top = 6.dp))
            Slider(
                value = p.tempLimit.toFloat(),
                onValueChange = { v -> vm.updateActive { it.copy(tempLimit = v.toInt()) } },
                valueRange = 38f..50f, steps = 11,
                colors = SliderDefaults.colors(thumbColor = Neon, activeTrackColor = Neon)
            )
        }

        NeonCard {
            SectionTitle("REGISTRO")
            if (game.log.isEmpty()) Text("Sem eventos ainda.", color = TextDim, fontSize = 12.sp)
            game.log.take(25).forEach { Text("• $it", color = TextDim, fontSize = 12.sp) }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("CONFIGURAÇÕES", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)

        NeonCard {
            SectionTitle("SHIZUKU (ADB sem PC, sem root)")
            Text(
                when (vm.shizuku) {
                    2 -> "Ativo e autorizado."
                    1 -> "Shizuku rodando, mas este app ainda não tem autorização."
                    else -> "Shizuku não está rodando."
                },
                color = if (vm.shizuku == 2) Good else Warn, fontWeight = FontWeight.Bold
            )
            Text(
                "Necessário para: desativar/reativar apps, restringir segundo plano, force-stop, ver consumo de RAM por app, " +
                    "CPU/GPU, modo de desempenho e medição de frames. Você autoriza dentro do Shizuku e pode revogar quando quiser.",
                color = TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            when (vm.shizuku) {
                1 -> NeonButton("AUTORIZAR O SHIZUKU") { Shell.request() }
                0 -> NeonButton("ABRIR O SHIZUKU", filled = false) {
                    if (!launchApp(ctx, "moe.shizuku.privileged.api")) vm.message = "Instale o Shizuku (Play Store/GitHub) e inicie-o por Depuração sem fio."
                }
                else -> {}
            }
        }

        NeonCard {
            SectionTitle("ACESSO DE USO")
            Text(
                if (vm.usage) "Concedido: o app detecta qual jogo está aberto." else "Não concedido: necessário para identificar o jogo aberto.",
                color = if (vm.usage) Good else Warn, fontWeight = FontWeight.Bold
            )
            if (!vm.usage) {
                Spacer(Modifier.height(8.dp))
                NeonButton("ABRIR AJUSTE", filled = false) {
                    ctx.startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        NeonCard {
            SectionTitle("SEGURANÇA")
            ToggleRow(
                "Permitir desativar apps de sistema",
                "Desligado: apps de sistema só são restringidos/encerrados. Apps essenciais (sistema, launcher, teclado, telefone, SMS, Google Play Services) NUNCA são tocados.",
                vm.allowSys
            ) { vm.setAllowSys(it) }
            Spacer(Modifier.height(6.dp))
            Text("Alterações pendentes de restauração: ${vm.pending}", color = Color.White)
            Spacer(Modifier.height(8.dp))
            NeonButton("RESTAURAR TUDO AGORA", color = Good, enabled = !vm.busy) { vm.restoreNow() }
        }

        NeonCard {
            SectionTitle("TRANSPARÊNCIA")
            Text(
                "• Nada é simulado: valores sem fonte real aparecem como \"indisponível\".\n" +
                    "• Sem root. Tudo que o app altera fica registrado e é desfeito ao encerrar o Game Mode ou em \"Restaurar tudo\".\n" +
                    "• Se o celular reiniciar no meio de uma sessão, abra o app e toque em Restaurar tudo.\n" +
                    "• Apps desativados por engano também podem ser reativados em Ajustes > Apps do Android.",
                color = TextDim, fontSize = 12.sp
            )
        }
    }
}
