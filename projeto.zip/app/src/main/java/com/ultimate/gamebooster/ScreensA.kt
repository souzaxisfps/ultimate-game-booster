package com.ultimate.gamebooster

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*

@Composable
fun HomeScreen(vm: MainViewModel, go: (Int) -> Unit) {
    val game by Engine.state.collectAsState()
    val s = vm.sample
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.65f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "a"
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ULTIMATE GAME BOOSTER", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        Text(
            if (game.active) "GAME MODE ATIVO • ${game.profileName}" else "Perfil selecionado: ${vm.active.name}",
            color = if (game.active) Good else TextDim
        )

        if (vm.shizuku != 2) {
            NeonCard(Modifier.clickable { go(5) }) {
                Text("Recursos avançados desligados", color = Warn, fontWeight = FontWeight.Bold)
                Text(
                    "Sem o Shizuku o app só consegue encerrar processos. Toque para configurar.",
                    color = TextDim, fontSize = 13.sp
                )
            }
        }
        if (vm.pending > 0 && !game.active) {
            NeonCard {
                Text("${vm.pending} alteração(ões) do app ainda não restaurada(s)", color = Warn, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                NeonButton("RESTAURAR TUDO", filled = false, color = Warn, enabled = !vm.busy) { vm.restoreNow() }
            }
        }

        NeonCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Gauge(s?.usedPct, "RAM", "%")
                Gauge(s?.cpu, "CPU", "%", Good)
                Gauge(s?.tempC, "TEMP", "°", tempColor(s?.tempC), 60f)
            }
            Spacer(Modifier.height(8.dp))
            if (s != null) {
                Text("RAM: ${s.usedMb} / ${s.totalMb} MB usados (${s.availMb} MB livres)", color = TextDim, fontSize = 12.sp)
                Text(
                    "GPU: " + (s.gpu?.let { "${it.toInt()}%" } ?: "indisponível neste aparelho/sem Shizuku"),
                    color = TextDim, fontSize = 12.sp
                )
                if (s.cpu == null) Text("CPU: indisponível (o Android bloqueia; use o Shizuku).", color = TextDim, fontSize = 12.sp)
            }
        }

        NeonCard {
            SectionTitle("RAM EM TEMPO REAL (%)")
            LineChart(vm.ramHist)
            SectionTitle("CPU (%)")
            LineChart(vm.cpuHist, color = Good)
            SectionTitle("TEMPERATURA (°C)")
            LineChart(vm.tempHist, max = 60f, color = Warn)
        }

        val fg = s?.fgPkg?.let { p -> vm.apps.firstOrNull { it.pkg == p }?.label ?: p }
        Text(
            when {
                !vm.usage -> "Dica: ative o acesso de uso em Configurações para detectar o jogo aberto."
                fg != null -> "App em primeiro plano: $fg"
                else -> "Nenhum app detectado ainda."
            },
            color = TextDim, fontSize = 12.sp
        )

        if (game.active) {
            NeonButton("ENCERRAR GAME MODE E RESTAURAR", color = Bad) { vm.stopGame() }
        } else {
            NeonButton("INICIAR GAME MODE", color = Neon.copy(alpha = pulse)) { vm.startGame() }
        }
    }
}

@Composable
fun AppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var showSys by remember { mutableStateOf(false) }
    var onlySel by remember { mutableStateOf(false) }
    val sel = vm.active.apps
    val list = vm.apps.filter {
        (showSys || !it.isSystem || it.pkg in sel) &&
            (!onlySel || it.pkg in sel) &&
            (q.isBlank() || it.label.contains(q, true) || it.pkg.contains(q, true))
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("GERENCIADOR DE APLICATIVOS", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            ProfileSelector(vm)
            Text(
                "${sel.size} selecionado(s) no perfil ${vm.active.name}. Apps essenciais ficam bloqueados.",
                color = TextDim, fontSize = 12.sp
            )
            OutlinedTextField(
                q, { q = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Buscar app") }, leadingIcon = { Icon(Icons.Rounded.Search, null) }
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(showSys, { showSys = !showSys }, { Text("Apps de sistema") })
                Spacer(Modifier.width(8.dp))
                FilterChip(onlySel, { onlySel = !onlySel }, { Text("Só selecionados") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.selectMany(list.filter { !it.isProtected }.map { it.pkg }) },
                    modifier = Modifier.weight(1f)
                ) { Text("Marcar visíveis", fontSize = 12.sp) }
                OutlinedButton(onClick = { vm.clearApps() }, modifier = Modifier.weight(1f)) {
                    Text("Limpar", fontSize = 12.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { vm.applySelectedNow() }, enabled = !vm.busy && sel.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black)
                ) { Text("Desativar agora", fontSize = 12.sp) }
                Button(
                    onClick = { vm.restoreNow() }, enabled = !vm.busy,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Good, contentColor = Color.Black)
                ) { Text("Reativar tudo (${vm.pending})", fontSize = 12.sp) }
            }
        }
        if (vm.loadingApps) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Neon)
        LazyColumn(Modifier.weight(1f)) {
            items(list, key = { it.pkg }) { a ->
                val tags = buildList {
                    if (a.isProtected) add("ESSENCIAL (bloqueado)")
                    else if (a.isSystem) add(if (vm.allowSys) "SISTEMA" else "SISTEMA (só restringe)")
                    if (!a.enabled) add("DESATIVADO")
                }
                Row(
                    Modifier.fillMaxWidth()
                        .clickable(enabled = !a.isProtected) { vm.toggleApp(a.pkg) }
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(a.pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.label, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(a.pkg, color = TextDim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (tags.isNotEmpty()) Text(tags.joinToString(" • "), color = if (a.isProtected) Warn else NeonDim, fontSize = 10.sp)
                    }
                    IconButton(onClick = { openAppInfo(ctx, a.pkg) }) { Icon(Icons.Rounded.Info, "Informações", tint = TextDim) }
                    if (a.isProtected) Icon(Icons.Rounded.Lock, null, tint = TextDim)
                    else Checkbox(
                        checked = a.pkg in sel, onCheckedChange = { vm.toggleApp(a.pkg) },
                        colors = CheckboxDefaults.colors(checkedColor = Neon, checkmarkColor = Color.Black)
                    )
                }
            }
        }
    }
}
