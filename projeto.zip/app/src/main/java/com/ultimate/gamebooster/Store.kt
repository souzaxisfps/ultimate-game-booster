package com.ultimate.gamebooster

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ugb", Context.MODE_PRIVATE)

    companion object {
        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store = inst ?: synchronized(this) {
            inst ?: Store(ctx.applicationContext).also { inst = it }
        }

        fun defaults(): List<Profile> = listOf(
            Profile("equilibrado", "EQUILIBRADO", true,
                disableApps = false, restrictBackground = true, killBackground = true,
                gameMode = false, reduceAnimations = false, tempLimit = 45),
            Profile("desempenho", "DESEMPENHO", true,
                disableApps = true, restrictBackground = true, killBackground = true,
                gameMode = true, reduceAnimations = false, tempLimit = 43),
            Profile("ultra", "ULTRA GAMING", true,
                disableApps = true, restrictBackground = true, killBackground = true,
                gameMode = true, reduceAnimations = true, tempLimit = 42)
        )
    }

    var activeId: String
        get() = sp.getString("active", "desempenho") ?: "desempenho"
        set(v) { sp.edit().putString("active", v).apply() }

    var allowSystemDisable: Boolean
        get() = sp.getBoolean("sysdis", false)
        set(v) { sp.edit().putBoolean("sysdis", v).apply() }

    var gamePkg: String
        get() = sp.getString("game", "") ?: ""
        set(v) { sp.edit().putString("game", v).apply() }

    @Synchronized
    fun profiles(): List<Profile> {
        val raw = sp.getString("profiles", null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            val out = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val apps = o.getJSONArray("apps")
                Profile(
                    id = o.getString("id"), name = o.getString("name"), builtIn = o.getBoolean("builtIn"),
                    apps = (0 until apps.length()).map { apps.getString(it) }.toSet(),
                    disableApps = o.getBoolean("disableApps"),
                    restrictBackground = o.getBoolean("restrictBackground"),
                    killBackground = o.getBoolean("killBackground"),
                    gameMode = o.getBoolean("gameMode"),
                    reduceAnimations = o.getBoolean("reduceAnimations"),
                    tempLimit = o.getInt("tempLimit")
                )
            }
            if (out.isEmpty()) defaults() else out
        } catch (e: Exception) {
            defaults()
        }
    }

    @Synchronized
    fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("builtIn", p.builtIn)
                put("apps", JSONArray(p.apps.toList()))
                put("disableApps", p.disableApps); put("restrictBackground", p.restrictBackground)
                put("killBackground", p.killBackground); put("gameMode", p.gameMode)
                put("reduceAnimations", p.reduceAnimations); put("tempLimit", p.tempLimit)
            })
        }
        sp.edit().putString("profiles", arr.toString()).apply()
    }

    @Synchronized
    fun changes(): MutableList<Change> {
        val raw = sp.getString("changes", null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Change(o.getString("t"), o.getString("k"), o.getString("o"))
            }.toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun saveChanges(list: List<Change>) {
        val arr = JSONArray()
        list.forEach { c -> arr.put(JSONObject().put("t", c.type).put("k", c.key).put("o", c.original)) }
        // commit() para garantir que o registro seja gravado antes de qualquer falha
        sp.edit().putString("changes", arr.toString()).commit()
    }
}
