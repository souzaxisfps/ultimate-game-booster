# ULTIMATE GAME BOOSTER

App Android (Kotlin + Jetpack Compose, Android 10+) para desativar apps temporariamente durante jogos, monitorar RAM/CPU/GPU/temperatura e restaurar tudo com um botão. Sem root.

## Gerar o APK pelo GitHub (pelo celular)
1. Crie um repositório novo no GitHub.
2. Envie para a raiz do repositório os arquivos `projeto.zip` (Add file > Upload files).
3. Crie o arquivo `.github/workflows/build.yml` (Add file > Create new file; digite o nome com as barras) e cole o conteúdo do `build.yml`.
4. Aba **Actions** > **Build APK** > **Run workflow**. Em alguns minutos, abra a execução e baixe **UltimateGameBooster-APK** (Artifacts). Descompacte e instale o `.apk`.

## Permissões (todas explicadas no app)
| Recurso | Precisa de |
|---|---|
| Listar apps, ícones, info | `QUERY_ALL_PACKAGES` (automática) |
| Detectar o jogo aberto | Acesso de uso (você ativa em Configurações) |
| Desativar/reativar apps, restringir segundo plano, force-stop, RAM por app, CPU/GPU, modo de desempenho, frames | **Shizuku** (você autoriza) |
| Encerrar processos sem Shizuku | `KILL_BACKGROUND_PROCESSES` (automática) |
| Notificação do Game Mode | Notificações |

## Como usar
1. Instale o Shizuku, inicie por Depuração sem fio e autorize o app em Configurações.
2. Aba **Apps**: escolha o perfil e marque os apps. Apps essenciais ficam bloqueados.
3. Aba **Game**: escolha o jogo alvo e toque em **INICIAR GAME MODE**.
4. Ao terminar: **ENCERRAR E RESTAURAR TUDO** (ou "Restaurar tudo" em Configurações).

## Limites honestos
- FPS real só aparece se o jogo informar frames ao Android; senão o app diz que é indisponível.
- GPU só em aparelhos Adreno (leitura kgsl). CPU precisa do Shizuku.
- Modo de desempenho do sistema depende do aparelho; se não aceitar, o app avisa no registro.
